{
	name: "Charizardite Y",
	spritenum: 586,
	megaStone: "Charizard-Mega-Y",
	megaEvolves: ["Charizard","Charizard-Drake"],
	itemUser: ["Charizard"],
	onTakeItem(item, source) {
		if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
		return true;
	},
	num: 678,
	gen: 6,
	isNonstandard: "Past"
}

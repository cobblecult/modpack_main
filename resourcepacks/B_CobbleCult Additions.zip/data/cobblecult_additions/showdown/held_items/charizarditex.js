{
    name: "Charizardite X",
    spritenum: 585,
    megaStone: "Charizard-Mega-X",
    megaEvolves: ["Charizard","Charizard-Drake"],
    itemUser: ["Charizard"],
    onTakeItem(item, source) {
        if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
        return true;
    },
    num: 660,
    gen: 6,
    isNonstandard: "Past"
}

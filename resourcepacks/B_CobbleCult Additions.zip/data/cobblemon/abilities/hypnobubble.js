{
  onModifyMove(move) {
    if (move.type === 'Psychic' && move.category !== 'Status') {
      if (!move.secondaries) move.secondaries = [];
      move.secondaries.push({
        chance: 10,
        status: 'slp',
        ability: this.dex.abilities.get('hypnobubble'),
      });
    }

    if (move.id === 'hypnosis' && typeof move.accuracy === 'number') {
      move.accuracy = 90;
    }
  },
  flags: {},
  name: "Hypno Bubble",
  rating: 3,
  num: -1000,
  onModifyMovePriority: -1,
}

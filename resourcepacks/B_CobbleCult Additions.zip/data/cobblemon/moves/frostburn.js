{
    num: -0654,
    name: "Frostburn",
    id: "frostburn",
    type: "Ice",
    category: "Special",
    basePower: 80,
    accuracy: 100,
    pp: 10,
    priority: 0,
    secondary: {
        chance: 30,
        status: 'brn',
    },
    target: "normal",
    flags: {protect:1, mirror:1},
    shortDesc: "30% chance to burn the target.",
}